<?php
/*
Plugin Name: Tamsaek Tracker
Description: 외부 유입 리퍼러 및 검색어 통계 수집 + 관리자 통계 시각화
Version: 1.1
Author: Tamsaek
*/


/* * ==========================================
 * 🚀 GitHub 기반 자동 업데이트 (Public Repo)
 * ==========================================
 */

// ✅ GitHub의 info.json "Raw" 주소 입력
// 형식: https://raw.githubusercontent.com/{아이디}/{저장소명}/main/info.json
define('TAMSAEK_UPDATE_URL', 'https://raw.githubusercontent.com/azit4u/Tamsaek-tracker/main/info.json');

// 현재 버전 (업데이트 할 때마다 이 숫자를 올려야 함)
define('TAMSAEK_CURRENT_VERSION', '1.1'); 

add_filter('pre_set_site_transient_update_plugins', 'tamsaek_check_for_update');
add_filter('plugins_api', 'tamsaek_plugin_info', 10, 3);

function tamsaek_check_for_update($transient) {
    if (empty($transient->checked)) return $transient;

    // GitHub에서 JSON 데이터 가져오기
    $remote = wp_remote_get(TAMSAEK_UPDATE_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json']
    ]);

    if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200 || empty($remote['body'])) {
        return $transient;
    }

    $remote = json_decode($remote['body']);

    // 버전 비교
    if ($remote && version_compare(TAMSAEK_CURRENT_VERSION, $remote->version, '<')) {
        $res = new stdClass();
        $res->slug = 'Tamsaek-tracker'; // 폴더명과 일치해야 함
        $res->plugin = 'Tamsaek-tracker/Tamsaek-tracker.php';
        $res->new_version = $remote->version;
        $res->package = $remote->download_url; // JSON에 적힌 zip 주소
        
        $transient->response[$res->plugin] = $res;
    }

    return $transient;
}

function tamsaek_plugin_info($res, $action, $args) {
    if ($action !== 'plugin_information') return $res;
    if ($args->slug !== 'Tamsaek-tracker') return $res;

    $remote = wp_remote_get(TAMSAEK_UPDATE_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json']
    ]);

    if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200 || empty($remote['body'])) {
        return $res;
    }

    $remote = json_decode($remote['body']);
    if ($remote) {
        $res = new stdClass();
        $res->name = $remote->name;
        $res->slug = 'Tamsaek-tracker';
        $res->version = $remote->version;
        $res->author = $remote->author;
        $res->download_link = $remote->download_url;
        $res->sections = [
            'description' => $remote->sections->description,
            'changelog' => $remote->sections->changelog
        ];
        return $res;
    }
    return $res;
}




define('TAMSAEK_TRACKER_PATH', plugin_dir_path(__FILE__));
define('TAMSAEK_TRACKER_URL', plugin_dir_url(__FILE__));



// 공통 기능 로드
require_once TAMSAEK_TRACKER_PATH . 'includes/logger.php';
require_once TAMSAEK_TRACKER_PATH . 'includes/enqueue.php';
require_once TAMSAEK_TRACKER_PATH . 'includes/menu.php';

register_activation_hook(__FILE__, 'tamsaek_create_referrer_table');

function tamsaek_create_referrer_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'referrer_stats';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        log_date DATE NOT NULL,
        ip_address VARCHAR(45) DEFAULT NULL,
        referer TEXT DEFAULT NULL,
        referer_path TEXT DEFAULT NULL,
        referer_query TEXT DEFAULT NULL,
        search_engine VARCHAR(20) DEFAULT NULL,
        keyword TEXT DEFAULT NULL,
        landing_page TEXT DEFAULT NULL,
        post_id BIGINT(20) DEFAULT NULL,
        device_type ENUM('pc','mobile') DEFAULT 'pc',
        user_agent TEXT DEFAULT NULL,
        ref_domain VARCHAR(255) DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        social_platform VARCHAR(50) DEFAULT '',
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

