<?php
add_action('admin_enqueue_scripts', function($hook) {
    if (isset($_GET['page']) && in_array($_GET['page'], ['referrer-paths', 'referrer-stats'])) {
        wp_enqueue_style('tamsaek-tracker-admin', TAMSAEK_TRACKER_URL . 'assets/admin.css', [], '1.0');
    }
});
