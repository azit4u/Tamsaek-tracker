<?php
/**
 * Plugin Name: Tamsaek Referrer Stats
 * Description: 워드프레스 관리자에 유입 통계 페이지 + AJAX 차트
 */

/*
// ✅ 1. 글 목록에 '조회수' 열(Column) 추가
add_filter('manage_posts_columns', 'tamsaek_add_view_count_column');
function tamsaek_add_view_count_column($columns) {
    $new_columns = array();
    
    // '날짜(date)' 컬럼 앞에 '조회수'를 끼워 넣기 위한 반복문
    foreach($columns as $key => $title) {
        if ($key == 'date') {
            $new_columns['tamsaek_views'] = '조회수(탐색)';
        }
        $new_columns[$key] = $title;
    }
    return $new_columns;
}

// ✅ 2. 각 글의 ID(post_id)를 이용해 DB에서 조회수 카운트 및 표시
add_action('manage_posts_custom_column', 'tamsaek_render_view_count', 10, 2);
function tamsaek_render_view_count($column_name, $post_id) {
    if ($column_name === 'tamsaek_views') {
        global $wpdb;
        $table = $wpdb->prefix . 'referrer_stats';
        
        // 해당 post_id를 가진 로그의 개수를 직접 셉니다 (가장 정확함)
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE post_id = %d", 
            $post_id
        ));

        // 숫자가 0이면 회색, 있으면 굵은 글씨로 표시
        if ($count > 0) {
            echo '<strong style="color:#0073aa;">' . number_format($count) . '</strong>';
        } else {
            echo '<span style="color:#ccc;">-</span>';
        }
    }
}

// ✅ 3. 관리자 페이지 CSS (조회수 컬럼 너비 조정)
add_action('admin_head', 'tamsaek_admin_column_style');
function tamsaek_admin_column_style() {
    $screen = get_current_screen();
    if ($screen && $screen->base === 'edit' && $screen->post_type === 'post') {
        echo '<style>
            .column-tamsaek_views {
                width: 80px !important;
                text-align: right !important;
                padding-right: 20px !important;
            }
        </style>';
    }
}

*/



function render_referrer_stats_page() {
    global $wpdb;

    tamsaek_render_summary_stats();

    $default = current_time('Y-m-d');

    $start_date = $_GET['start_date'] ?? date("Y-m-d", strtotime('-6 days', strtotime($default)));
    $end_date = $_GET['end_date'] ?? $default;
    $chart_data = tamsaek_get_stacked_chart_data($start_date, $end_date);
    ?>

    <div class="wrap">
        <h1>📊 유입 통계</h1>

        <script>ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";</script>

        <div id="chart-tabs">
            <button class="button chart-tab active" data-type="daily">일간</button>
            <button class="button chart-tab" data-type="weekly">주간</button>
            <button class="button chart-tab" data-type="monthly">월간</button>
        </div>

        <div id="date-nav">
            <button id="prev-date" class="button">◀ 이전</button>
            <strong id="current-range"><?php echo esc_html("$start_date ~ $end_date"); ?></strong>
            <button id="next-date" class="button">다음 ▶</button>
        </div>

        <div style="position:relative;height:400px;">
            <canvas id="dailyChart"></canvas>
        </div>

        <div id="log-detail" style="margin-top:20px;"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        let chartType = 'daily';
        let currentStart = '<?php echo $start_date; ?>';
        let currentEnd = '<?php echo $end_date; ?>';
        let selectedBarIndex = null;

        let selectedStart = '';
        let selectedEnd = '';

        const ctx = document.getElementById('dailyChart').getContext('2d');
        const colorMap = {
            search: { normal: 'rgba(255, 99, 132, 0.5)', selected: 'rgba(255, 99, 132, 1)' },
            sns:    { normal: 'rgba(75, 192, 75, 0.5)', selected: 'rgba(75, 192, 75, 1)' },
            etc:    { normal: 'rgba(180,180,180,0.5)', selected: 'rgba(180,180,180,1)' }
        };

        function updateBarColors() {
            chart.data.datasets.forEach((dataset, datasetIndex) => {
                dataset.backgroundColor = dataset.data.map((v, i) => {
                    const isSelected = i === selectedBarIndex;

                    if (dataset.label === '검색 유입') {
                        return isSelected ? colorMap.search.selected : colorMap.search.normal;
                    }
                    if (dataset.label === 'SNS 유입') {
                        return isSelected ? colorMap.sns.selected : colorMap.sns.normal;
                    }
                    return isSelected ? colorMap.etc.selected : colorMap.etc.normal;
                });
            });

            chart.update();
        }

        let chart = new Chart(ctx, {
            type: 'bar',
            data: { labels: [], datasets: [] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                onClick: (evt) => {
                    const points = chart.getElementsAtEventForMode(evt, 'nearest', { intersect: false }, false);
                    if (!points.length) return;

                    const index = points[0].index;
                    const label = chart.data.labels[index];
                    selectedBarIndex = index; // ✅ 클릭된 인덱스 기억

                    let start = label;
                    let end = label;

                    if (chartType === 'weekly') {
                        const base = new Date(currentStart);
                        base.setDate(base.getDate() + (index * 7));
                        start = formatDate(base);
                        const endDate = new Date(base);
                        endDate.setDate(endDate.getDate() + 6);
                        end = formatDate(endDate);
                    } else if (chartType === 'monthly') {
                        start = label + '-01';
                        const endDate = new Date(start);
                        endDate.setMonth(endDate.getMonth() + 1);
                        endDate.setDate(0);
                        end = formatDate(endDate);
                    }

                    selectedStart = start;
                    selectedEnd = end;
                    fetchReferrerDetail(start, end, chartType);

                    updateBarColors(); // ✅ 색상 반영
                },
                onHover: (event, elements) => {
                    event.native.target.style.cursor = elements.length ? 'pointer' : 'default';
                },
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: ctx => ctx.dataset.label + ': ' + ctx.formattedValue + '회'
                        }
                    },
                    legend: { position: 'top' }
                },
                scales: {
                    x: { stacked: true },
                    y: { stacked: true, beginAtZero: true }
                }
            }
        });

        function formatDate(d) {
            return d.toISOString().slice(0, 10);
        }

        function getStartOfWeek(d) {
            const day = d.getDay();
            const diff = d.getDate() - day + (day === 0 ? -6 : 1); // 월요일 기준
            return new Date(d.setDate(diff));
        }

        function shiftDateRange(days) {
            const s = new Date(currentStart);
            const e = new Date(currentEnd);

            s.setDate(s.getDate() + days);
            e.setDate(e.getDate() + days);

            currentStart = formatDate(s);
            currentEnd = formatDate(e);

            loadChartData(currentStart, currentEnd, chartType);
        }
		
		function shiftMonthRange(months) {
			const base = parseLocalDate(currentStart);
			const start = new Date(base.getFullYear(), base.getMonth() + months, 1); // 매번 1일 고정
			const end = new Date(start.getFullYear(), start.getMonth() + 1, 0); // 말일 구하기

			currentStart = formatDate(start);
			currentEnd = formatDate(end);

			loadChartData(currentStart, currentEnd, 'monthly');
		}
		
		let currentMonthOffset = 0; // 현재 기준 = 0, 이전은 -12, 그 전은 -24...

		function getMonthlyRange(offsetInMonths = 0) {
			const today = getTodayLocalDate(); // YYYY-MM-DD
			const todayDate = new Date(today);

			// 기준: 이번달 1일
			const base = new Date(todayDate.getFullYear(), todayDate.getMonth(), 1);
			base.setMonth(base.getMonth() + offsetInMonths - 11); // 과거로 11개월 전부터

			// 시작일: 무조건 해당 월 1일
			const start = new Date(base.getFullYear(), base.getMonth(), 1);

			// 종료일: 12개월 뒤의 첫날 -1일 = 정확한 12개월 말일
			const tmp = new Date(start.getFullYear(), start.getMonth() + 12, 1);
			tmp.setDate(tmp.getDate() - 1); // → 말일 보정
			const end = tmp;

			//console.log('[CHECK]', start.toString(), end.toString());

			return {
				start: formatDate(start),
				end: formatDate(end)
			};
		}

		function formatDate(date) {
			const yyyy = date.getFullYear();
			const mm = String(date.getMonth() + 1).padStart(2, '0');
			const dd = String(date.getDate()).padStart(2, '0');
			return `${yyyy}-${mm}-${dd}`;
		}


        function getTodayLocalStr() {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        function getTodayLocalDate() {
            const now = new Date();
            return new Date(now.getFullYear(), now.getMonth(), now.getDate()); // 오전 0시
        }

        function parseLocalDate(yyyy_mm_dd) {
            const [y, m, d] = yyyy_mm_dd.split('-').map(Number);
            return new Date(y, m - 1, d);
        }

        function loadChartData(start, end, type) {
            let labelRange = '';

            if (type === 'monthly') {
                labelRange = start.slice(0, 7) + ' ~ ' + end.slice(0, 7);
            } else {
                labelRange = start + ' ~ ' + end;
            }

            document.getElementById('current-range').innerText = labelRange;

            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: new URLSearchParams({
                    action: 'get_referrer_chart_data',
                    start_date: start,
                    end_date: end,
                    type: type
                })
            })
            .then(res => res.json())
            .then(res => {
                if (res.success) {
                    //console.log('[SQL]', res.data.sql); // 실제 실행된 쿼리 출력

                    selectedBarIndex = null;
                    const d = res.data;
                    const labels = [...d.labels]; // 복사본 만들기
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);

                    if (labels.length) {
                        const lastIndex = labels.length - 1;
                        let lastLabel = labels[lastIndex];

                        if (type === 'daily') {
                            const todayStr = getTodayLocalStr(); // 로컬 기준 오늘
                            const lastIndex = d.labels.length - 1;
                            const lastLabel = d.labels[lastIndex];
                           // console.log('[라스트라벨]', lastLabel, '[오늘]', todayStr);

                         
                        } else if (type === 'weekly') {
                            const today = getTodayLocalDate(); // ✅ 브라우저 기준 '오늘'
                            const thisWeekMonday = getStartOfWeek(today);
                            const thisWeekSunday = new Date(thisWeekMonday);
                            thisWeekSunday.setDate(thisWeekMonday.getDate() + 6);

                            const lastIndex = d.labels.length - 1;
                            const lastStart = new Date(currentStart);
                            lastStart.setDate(lastStart.getDate() + lastIndex * 7);
                            const lastEnd = new Date(lastStart);
                            lastEnd.setDate(lastStart.getDate() + 6);

                            // 오늘이 라벨 범위 안에 포함되면 '(이번주)' 표시
                        
                        } else if (type === 'monthly') {
                            const today = getTodayLocalDate(); // ✅ 브라우저 기준 오늘
                            const thisMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;

                            const lastIndex = d.labels.length - 1;
                         
                        }
                    }
                    chart.data.labels = d.labels;
                    chart.data.datasets = [
                        {
                            label: '검색 유입',
                            data: d.search_views,
                            backgroundColor: 'rgba(255, 99, 132, 0.8)',
                            stack: 'total'
                        },
                        {
                            label: 'SNS 유입',
                            data: d.sns_views,
                            backgroundColor: 'rgba(75, 192, 75, 0.8)',
                            stack: 'total'
                        },
                        {
                            label: '기타 유입',
                            data: d.total_views.map((t, i) => {
                                const known = d.search_views[i] + d.sns_views[i];
                                return t > known ? t - known : 0;
                            }),
                            backgroundColor: 'rgba(180,180,180,0.8)',
                            stack: 'total'
                        }
                    ];
                    chart.update();

                    // ✅ 자동으로 최신 날짜 기준 상세 데이터 로드
                    const lastIndex = chart.data.labels.length - 1;
                    let startLabel = chart.data.labels[lastIndex];
                    let endLabel = chart.data.labels[lastIndex];
                    selectedBarIndex = lastIndex; // ✅ 초기 선택 설정
                    updateBarColors();            // ✅ 색상 반영

                    if (type === 'weekly') {
                        const base = new Date(currentStart);
                        base.setDate(base.getDate() + (lastIndex * 7));
                        startLabel = formatDate(base);
                        const endDate = new Date(base);
                        endDate.setDate(endDate.getDate() + 6);
                        endLabel = formatDate(endDate);
                    } else if (type === 'monthly') {
                        startLabel = chart.data.labels[lastIndex] + '-01';
                        const tmp = new Date(startLabel);
                        tmp.setMonth(tmp.getMonth() + 1);
                        tmp.setDate(0); // 말일
                        endLabel = formatDate(tmp);
                    }

                    selectedStart = startLabel;
                    selectedEnd = endLabel;

                    fetchReferrerDetail(startLabel, endLabel, type);

                    updateNextButtonState(); // ✅ 버튼 상태 갱신
                }
            });
        }

        function getStartOfWeek(d) {
            const day = d.getDay();
            const diff = d.getDate() - day + (day === 0 ? -6 : 1); // 월요일 기준
            return new Date(d.setDate(diff));
        }

        // ✅ 여기를 기존처럼 남겨두셨다면 바로 아래 코드 2줄을 "제거"하고,
        // 아래 새 코드로 대체하세요.
        // document.getElementById('prev-date').onclick = () => shiftDateRange(-7);
        // document.getElementById('next-date').onclick = () => shiftDateRange(7);

        // ✨ 아래로 교체
        document.getElementById('prev-date').onclick = () => {
             if (chartType === 'monthly') {
				currentMonthOffset -= 12;
				const range = getMonthlyRange(currentMonthOffset);
				currentStart = range.start;
				currentEnd = range.end;
				loadChartData(currentStart, currentEnd, chartType);
			} else {
				const days = chartType === 'weekly' ? -105 : -7;
				shiftDateRange(days);
			}
        };

        document.getElementById('next-date').onclick = () => {
            const today = getTodayLocalDate(); // 로컬 기준 오늘
            let disableNext = false;

            if (chartType === 'daily') {
                const testDate = parseLocalDate(currentEnd);
                testDate.setDate(testDate.getDate() + 1);
                disableNext = testDate > today;

            } else if (chartType === 'weekly') {
                const nextWeekStart = parseLocalDate(currentEnd);
                nextWeekStart.setDate(nextWeekStart.getDate() + 1);
                const nextWeekMonday = getStartOfWeek(nextWeekStart);
                const nextWeekSunday = new Date(nextWeekMonday);
                nextWeekSunday.setDate(nextWeekMonday.getDate() + 6);

                disableNext = today <= nextWeekSunday;

            } else if (chartType === 'monthly') {
                const nextMonthStart = parseLocalDate(currentEnd);
                nextMonthStart.setDate(1); // 안전하게 말일 대비
                nextMonthStart.setMonth(nextMonthStart.getMonth() + 1);

                const nextMonthEnd = new Date(nextMonthStart);
                nextMonthEnd.setMonth(nextMonthEnd.getMonth() + 1);
                nextMonthEnd.setDate(0); // 말일

                disableNext = today <= nextMonthEnd;
            }

            if (!disableNext) {
                if (chartType === 'monthly') {
					if (currentMonthOffset < 0) {
						currentMonthOffset += 12;
						const range = getMonthlyRange(currentMonthOffset);
						currentStart = range.start;
						currentEnd = range.end;
						loadChartData(currentStart, currentEnd, chartType);
					}
				} else {
					const days = chartType === 'weekly' ? 105 : 7;
					shiftDateRange(days);
				}
            }
        };

        function updateNextButtonState() {
            const btn = document.getElementById('next-date');
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            let testStart = parseLocalDate(currentEnd);
            testStart.setDate(testStart.getDate() + 1);

            let testEnd;

            if (chartType === 'weekly') {
                testStart = getStartOfWeek(testStart);
                testEnd = new Date(testStart);
                testEnd.setDate(testEnd.getDate() + 6); // 주간 종료일
            } else if (chartType === 'monthly') {
                testStart.setDate(1);
                testStart.setMonth(testStart.getMonth() + 1);
                testEnd = new Date(testStart);
                testEnd.setMonth(testEnd.getMonth() + 1);
                testEnd.setDate(0); // 말일
            } else {
                testEnd = new Date(currentEnd);
                testEnd.setDate(testEnd.getDate() + 1);
            }

            // 오늘 이후면 비활성화
            const disable = testStart > today;
            btn.disabled = disable;
        }

        document.querySelectorAll('.chart-tab').forEach(tab => {
            tab.onclick = e => {
                document.querySelectorAll('.chart-tab').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                chartType = e.target.dataset.type;

                const today = new Date();
                if (chartType === 'daily') {
                    const start = new Date(today);
                    start.setDate(today.getDate() - 6);
                    currentStart = formatDate(start);
                    currentEnd = formatDate(today);
                } else if (chartType === 'weekly') {
                    const today = new Date();

                    // 이번주 월요일
                    const thisWeekMonday = getStartOfWeek(today);

                    // 15주 전 월요일
                    const start = new Date(thisWeekMonday);
                    start.setDate(start.getDate() - (7 * 14)); // 🔥 14주 전 = 포함하면 총 15주

                    // 이번주 일요일
                    const end = new Date(thisWeekMonday);
                    end.setDate(end.getDate() + 6); // 이번주 마지막날 = 일요일

                    currentStart = formatDate(start); // 2025-03-24
                    currentEnd = formatDate(end);     // 2025-07-06
                } else {
                    const end = new Date(today);
                    const start = new Date(end);
                    start.setMonth(end.getMonth() - 11);
                    start.setDate(1);

                    // 🔥 수정 포인트: 해당 월의 마지막 날짜로 설정
                    end.setMonth(end.getMonth() + 1); // 다음 달로 이동
                    end.setDate(0); // 0일 = 이전 달의 마지막 날

                    currentStart = formatDate(start);
                    currentEnd = formatDate(end);
                }
                loadChartData(currentStart, currentEnd, chartType);
                updateNextButtonState(); // ✅ 추가
            };
        });

        loadChartData(currentStart, currentEnd, chartType);

        function fetchReferrerDetail(start, end, type, paged = 1) {
            const logDetail = document.getElementById('log-detail');

            if (!start) start = currentStart;
            if (!end) end = currentEnd;

            if (paged === 1) {
                logDetail.innerHTML = '⏳ 데이터 불러오는 중...';
            }

            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: new URLSearchParams({
                    action: 'get_referrer_detail',
                    start_date: start,
                    end_date: end,
                    type: type,
                    paged: paged
                })
            })
            .then(res => res.text())
            .then(html => {
                // ✅ 기존 더보기 버튼 제거
                const prevBtnWrap = document.querySelector('.ref-loadmore');
                if (prevBtnWrap) prevBtnWrap.remove();

                if (paged === 1) {
                    logDetail.innerHTML = html;
                } else {
                    document.querySelector('#popular-posts tbody').insertAdjacentHTML('beforeend', html);
                }
            });
        }

        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('load-more-btn')) {
                const btn = e.target;
                const nextPage = parseInt(btn.dataset.next, 10);

                // 👉 여기서 제거하지 말고 fetch 함수 내에서 제거
                const start = selectedStart || currentStart;
                const end = selectedEnd || currentEnd;
                fetchReferrerDetail(start, end, chartType, nextPage);
            }
        });
    </script>
    <?php
}

// 3. Ajax 핸들러 등록
add_action('wp_ajax_get_referrer_chart_data', 'ajax_get_referrer_chart_data');
function ajax_get_referrer_chart_data() {
    $start = sanitize_text_field($_POST['start_date']);
    $end = sanitize_text_field($_POST['end_date']);
    $type = sanitize_text_field($_POST['type'] ?? 'daily');

    // 통계 데이터 수집
    $data = tamsaek_get_stacked_chart_data($start, $end, $type);

    // 쿼리문 함께 반환
    wp_send_json_success(array_merge($data, [
        'sql' => $GLOBALS['wpdb']->last_query
    ]));
}

// 4. 통계 데이터 조회 함수
function tamsaek_get_stacked_chart_data($start_date = '', $end_date = '', $type = 'daily') {
    global $wpdb;
    $table = $wpdb->prefix . 'referrer_stats';

    if (!$end_date) $end_date = date('Y-m-d');
    if (!$start_date) $start_date = date('Y-m-d', strtotime('-6 days', strtotime($end_date)));

    $labels = [];
    $total_views = [];
    $search_views = [];
    $sns_views = [];

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT log_date, search_engine, social_platform
         FROM $table
         WHERE log_date BETWEEN %s AND %s",
        $start_date, $end_date
    ));

    if ($type === 'weekly') {
        // 주간: 월요일 기준
        $start = new DateTime($start_date);
        $end = new DateTime($end_date);
        $start->modify('monday this week');
        $end->modify('monday this week');
        $weeks = [];

        while ($start <= $end) {
            $key = $start->format('Y-W');
            $label_start = $start->format('m/d');
            $label_end = (clone $start)->modify('+6 days')->format('m/d');

            $weeks[$key] = [
                'label' => $label_start . ' ~ ' . $label_end,
                'views' => 0,
                'search' => 0,
                'sns' => 0
            ];
            $start->modify('+7 days');
        }

        foreach ($results as $row) {
            $monday = (new DateTime($row->log_date))->modify('monday this week')->format('Y-W');
            if (!isset($weeks[$monday])) continue;

            $weeks[$monday]['views'] += 1;
            if (!empty($row->search_engine)) {
                $weeks[$monday]['search'] += 1;
            } elseif (!empty($row->social_platform)) {
                $weeks[$monday]['sns'] += 1;
            }
        }

        foreach ($weeks as $w) {
            $labels[] = $w['label'];
            $total_views[] = $w['views'];
            $search_views[] = $w['search'];
            $sns_views[] = $w['sns'];
        }

    } else if ($type === 'monthly') {
        // 월간: 월 단위 라벨 생성
        $start = new DateTime($start_date);
        $start->modify('first day of this month');

        $end = new DateTime($end_date);
        $end->modify('first day of next month'); // 마지막 달까지 포함

        $months = [];

        while ($start < $end) {
            $key = $start->format('Y-m');
            $months[$key] = [
                'label' => $key,
                'views' => 0,
                'search' => 0,
                'sns' => 0
            ];
            $start->modify('+1 month');
        }

        // 날짜별 raw 데이터 누적
        foreach ($results as $row) {
            $key = (new DateTime($row->log_date))->format('Y-m');
            if (!isset($months[$key])) continue;

            $months[$key]['views'] += 1;
            if (!empty($row->search_engine)) {
                $months[$key]['search'] += 1;
            } elseif (!empty($row->social_platform)) {
                $months[$key]['sns'] += 1;
            }
        }

        // 결과 정리
        foreach ($months as $m) {
            $labels[] = $m['label'];
            $total_views[] = $m['views'];
            $search_views[] = $m['search'];
            $sns_views[] = $m['sns'];
        }
    } else {
        // 일간
        $period = new DatePeriod(
            new DateTime($start_date),
            new DateInterval('P1D'),
            (new DateTime($end_date))->modify('+1 day')
        );

        $days = [];
        foreach ($period as $date) {
            $key = $date->format('Y-m-d');
            $days[$key] = [
                'label' => $key,
                'views' => 0,
                'search' => 0,
                'sns' => 0
            ];
        }

        foreach ($results as $row) {
            $key = $row->log_date;
            if (!isset($days[$key])) continue;

            $days[$key]['views'] += 1;
            if (!empty($row->search_engine)) {
                $days[$key]['search'] += 1;
            } elseif (!empty($row->social_platform)) {
                $days[$key]['sns'] += 1;
            }
        }

        foreach ($days as $d) {
            $labels[] = $d['label'];
            $total_views[] = $d['views'];
            $search_views[] = $d['search'];
            $sns_views[] = $d['sns'];
        }
    }

    return [
        'labels' => $labels,
        'total_views' => $total_views,
        'search_views' => $search_views,
        'sns_views' => $sns_views
    ];
}

add_action('wp_ajax_get_referrer_detail', 'tamsaek_get_referrer_detail');
function tamsaek_get_referrer_detail() {
    global $wpdb;

    $start = sanitize_text_field($_POST['start_date']);
    $end = sanitize_text_field($_POST['end_date']);
    $paged = intval($_POST['paged'] ?? 1);
    $limit = 10;
    $offset = ($paged - 1) * $limit;
    $table = $wpdb->prefix . 'referrer_stats';

    if ($paged === 1) {
        // 키워드 출력
        $kw_query = $wpdb->prepare("
            SELECT keyword, COUNT(*) as cnt
            FROM $table
            WHERE log_date BETWEEN %s AND %s AND keyword != ''
            GROUP BY keyword
            ORDER BY cnt DESC
        ", $start, $end);

        $keywords = $wpdb->get_results($kw_query);

        // 콘솔 로그 추가
        //echo '[SQL] 키워드 쿼리: '.$kw_query. '"';

        echo '<div class="ref-keywords"><h3>🔍 유입 키워드</h3><div class="tag-wrap">';
		$keywordNum = 0;
        foreach ($keywords as $row) {
			$keywordNum++;
            echo '<span class="tag">' . esc_html($row->keyword) . ' <em>' . $row->cnt . '</em></span>';
        }
		
		if($keywordNum == 0) {
			echo '<p class="tamsaek-none">유입 키워드가 없습니다.</p>';
		}
		
        echo '</div></div>';

        echo '<div class="ref-popular">';
        echo '<h3>📌 인기글</h3>';
        echo '<table id="popular-posts" class="ref-table"><thead><tr>
            <td>제목</td><td>조회</td>
        </tr></thead><tbody>';
    }

    $query = $wpdb->prepare("
        SELECT post_id, COUNT(*) as views
        FROM $table
        WHERE log_date BETWEEN %s AND %s
          AND post_id IS NOT NULL
        GROUP BY post_id
        ORDER BY views DESC, post_id ASC
        LIMIT %d OFFSET %d
    ", $start, $end, $limit, $offset);
    $raw_posts = $wpdb->get_results($query);

    // 콘솔 출력
    //echo '[SQL] 인기글 쿼리: ' . ($query) . '"';
	$best_postNum = 0;
    foreach ($raw_posts as $row) {
        $post_id = $row->post_id;
        if (!$post_id || get_post_status($post_id) !== 'publish') continue;
		$best_postNum++;
        $title = esc_html(get_the_title($post_id));
        $link = get_permalink($post_id);
        echo "<tr><td><a href='{$link}' target='_blank'>{$title}</a></td><td>{$row->views}</td></tr>";
    }
	
	if($best_postNum == 0) {
		echo '<tr><td colspan="2"><p class="tamsaek-none">인기글 데이터가 없습니다.</p></td></tr>';
	}

    if ($paged === 1) {
        echo '</tbody></table>'; // 테이블 닫기
    }

    // 총 페이지 수 계산
    $total_count = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(DISTINCT post_id)
        FROM $table
        WHERE log_date BETWEEN %s AND %s
              AND post_id IS NOT NULL
    ", $start, $end));
    $total_pages = ceil($total_count / $limit);

    // 더보기 버튼은 테이블 바깥에서 출력
    if ($paged < $total_pages) {
        echo '<div class="ref-loadmore"><button class="load-more-btn" data-next="' . ($paged + 1) . '">더보기 ⬇️</button></div>';
    }

    if ($paged === 1) {
        echo '</div>'; // .ref-popular 닫기
    }

    wp_die();
}

function tamsaek_render_summary_stats() {
    global $wpdb;
    $table = $wpdb->prefix . 'referrer_stats';

    // 날짜 계산
    $today = current_time('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    // 조회수 (전체 로그 수 기준)
    $total_views = $wpdb->get_var("SELECT COUNT(*) FROM $table");
    $today_views = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE log_date = %s", $today));
    $yesterday_views = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE log_date = %s", $yesterday));

    // 방문자수 (고유 IP 기준)
    $total_visitors = $wpdb->get_var("SELECT COUNT(DISTINCT ip_address) FROM $table");
    $today_visitors = $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT ip_address) FROM $table WHERE log_date = %s", $today));
    $yesterday_visitors = $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT ip_address) FROM $table WHERE log_date = %s", $yesterday));

    // 출력
    echo '<div class="tamsaek-summary-stats">';
    $stats = [
        '오늘 조회수' => $today_views,
        '어제 조회수' => $yesterday_views,
        '누적 조회수' => $total_views,
        '오늘 방문자' => $today_visitors,
        '어제 방문자' => $yesterday_visitors,
        '누적 방문자' => $total_visitors,
    ];
    foreach ($stats as $label => $value) {
        echo '<div class="stat-group">';
        echo '<div class="stat-label">' . esc_html($label) . '</div>';
        echo '<div class="stat-value">' . number_format($value) . '</div>';
        echo '</div>';
    }
    echo '</div>';
}
?>
