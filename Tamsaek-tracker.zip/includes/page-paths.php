<?php
function display_url_clean($url) {
    // 최대 두 번 디코딩
    $decoded = urldecode($url);
    if (preg_match('/%[0-9A-Fa-f]{2}/', $decoded)) {
        $decoded = urldecode($decoded);
    }

    // UTF-8로 유효한지 검사
    if (!mb_check_encoding($decoded, 'UTF-8')) {
        // 흔히 EUC-KR로 인코딩된 경우가 많음
        $decoded = mb_convert_encoding($decoded, 'UTF-8', 'EUC-KR');
    }

    return $decoded;
}

function render_referrer_path_page() {
    global $wpdb;
	
	// ✅ [추가] Flatpickr 라이브러리 (스타일 + 스크립트 + 한글팩)
    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">';
    echo '<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>';
    echo '<script src="https://npmcdn.com/flatpickr/dist/l10n/ko.js"></script>';

	
    $table = $wpdb->prefix . 'referrer_stats';

    // 📆 날짜 필터 처리
    $default = current_time('Y-m-d');
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : $default;
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : $start_date;

    // 🔥 도메인 필터 추가
    $selected_domain = isset($_GET['domain']) ? sanitize_text_field($_GET['domain']) : '';

    // ⏱️ 페이징 설정
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $limit = 30;
    $offset = ($paged - 1) * $limit;

    // 🔝 유입 도메인 TOP 10
    $top_domains = $wpdb->get_results($wpdb->prepare("
        SELECT ref_domain, COUNT(*) as cnt
        FROM $table
        WHERE log_date BETWEEN %s AND %s
        GROUP BY ref_domain
        ORDER BY cnt DESC
        LIMIT 10
    ", $start_date, $end_date));

    // 📄 전체 유입 수 (🔥 도메인 필터 반영)
    $total_sql = "
        SELECT COUNT(*) FROM $table
        WHERE log_date BETWEEN %s AND %s
    ";
    $args = [$start_date, $end_date];
    if ($selected_domain !== '') {
        $total_sql .= " AND ref_domain = %s";
        $args[] = $selected_domain;
    }
    $total = $wpdb->get_var($wpdb->prepare($total_sql, ...$args));
    $total_pages = ceil($total / $limit);

    // 📄 유입 로그 (🔥 도메인 필터 반영)
    $log_sql = "
        SELECT *
        FROM $table
        WHERE log_date BETWEEN %s AND %s
    ";
    $log_args = [$start_date, $end_date];
    if ($selected_domain !== '') {
        $log_sql .= " AND ref_domain = %s";
        $log_args[] = $selected_domain;
    }
    $log_sql .= " ORDER BY id DESC LIMIT %d OFFSET %d";
    $log_args[] = $limit;
    $log_args[] = $offset;

    $recent_logs = $wpdb->get_results($wpdb->prepare($log_sql, ...$log_args));

    echo '<div class="wrap">';
    echo '<h1>🛰️ 유입 경로</h1>';

    // ✅ [수정됨] 날짜 범위 선택 폼 (Flatpickr 적용)
    echo '<form method="get" id="tamsaek-filter-form" style="margin-bottom:20px; display:flex; align-items:center; gap:10px;">';
    echo '<input type="hidden" name="page" value="referrer-paths" />';
    
    // 실제 서버로 전송될 hidden 값 (기존 로직 호환용)
    echo '<input type="hidden" name="start_date" id="hidden_start_date" value="' . esc_attr($start_date) . '">';
    echo '<input type="hidden" name="end_date" id="hidden_end_date" value="' . esc_attr($end_date) . '">';

    if ($selected_domain !== '') {
        echo '<input type="hidden" name="domain" value="' . esc_attr($selected_domain) . '" />';
    }

    // 눈에 보이는 하나의 입력창
    echo '<div style="position:relative;">';
    echo '<span class="dashicons dashicons-calendar-alt" style="position:absolute; left:10px; top:50%; transform:translateY(-50%); color:#888; z-index:1;"></span>';
    echo '<input type="text" id="date-range-picker" class="regular-text" style="padding-left:34px; width:220px;" placeholder="기간을 선택하세요" value="' . esc_attr($start_date . ' ~ ' . $end_date) . '">';
    echo '</div>';

    echo '<input type="submit" class="button button-primary" value="검색">';
    echo '</form>';

    // ✅ [추가] Flatpickr 실행 스크립트
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        flatpickr("#date-range-picker", {
            mode: "range",          // 기간 선택 모드
            dateFormat: "Y-m-d",    // 날짜 형식
            defaultDate: ["<?php echo $start_date; ?>", "<?php echo $end_date; ?>"], // 현재 선택된 날짜 표시
            locale: "ko",           // 한글 설정
            onClose: function(selectedDates, dateStr, instance) {
                // 선택이 완료되면 숨겨진 input에 값을 쪼개서 넣음
                if (selectedDates.length === 2) {
                    const start = instance.formatDate(selectedDates[0], "Y-m-d");
                    const end = instance.formatDate(selectedDates[1], "Y-m-d");
                    document.getElementById('hidden_start_date').value = start;
                    document.getElementById('hidden_end_date').value = end;
                }
            }
        });
    });
    </script>
	<?php

    // 🔥 현재 도메인 필터 상태 및 해제 버튼
    if ($selected_domain !== '') {
		echo '<div style="margin-bottom:12px;">';
		echo '<b>도메인 필터:</b> ' . esc_html($selected_domain) . ' ';
		// domain만 제거한 현재 쿼리
		$query_args = $_GET;
		unset($query_args['domain']);
		$clear_url = add_query_arg($query_args, admin_url('admin.php'));
		echo '<a href="' . esc_url($clear_url) . '" class="button">전체보기</a>';
		echo '</div>';
    }

    echo '<div class="tamsaek-flex-wrap">';

    // 왼쪽: 도메인 순위 (🔥 도메인 클릭시 필터)
    echo '<div class="tamsaek-left">';
    echo '<h2>📌 유입 도메인 순위</h2>';
    echo '<table><thead><tr><th>순위</th><th>도메인</th><th>유입수</th></tr></thead><tbody>';
    $rank = 1;
    foreach ($top_domains as $row) {
        $domain_display = $row->ref_domain === "direct" ? "직접접속" : $row->ref_domain;
        // 🔥 순위 옆 링크 추가
        $domain_url = add_query_arg([
            'page' => 'referrer-paths',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'domain' => $row->ref_domain,
			'paged' => 1,
        ]);
        echo '<tr><td>' . $rank++ . '</td><td>            <a href="' . esc_url($domain_url) . '" style="color:inherit; text-decoration:underline;">'
            . esc_html($domain_display) .
            '</a></td><td>' . $row->cnt . '</td></tr>';
    }
    echo '</tbody></table></div>';

    // 오른쪽: 유입 로그
    echo '<div class="tamsaek-right">';
    echo '<h2>📖 유입 로그</h2>';
    echo '<table><thead><tr><th>링크</th><th>날짜</th></tr></thead><tbody>';
	foreach ($recent_logs as $log) {
		$favicon = '🔗';
		$prefix_icon = ''; // 소셜 플랫폼 접속 시 앞에 붙일 아이콘

		// 우선순위 1: social_platform 값이 존재할 경우
		if ($log->social_platform != '') {
			
			$prefix_icon = '📱'; // 소셜 접속 표시
			switch (strtolower($log->social_platform)) {
				case 'facebook':
					$favicon = '🟦';
					break;
				case 'instagram':
					$favicon = '🟪';
					break;
				case 'kakao':
				case 'kakaotalk':
				case 'kakaostory':
					$favicon = '🟨';
					break;
				case 'twitter':
					$favicon = '🐦';
					break;
				case 'linkedin':
					$favicon = '🧑‍💼';
					break;
				case 'pinterest':
					$favicon = '📌';
					break;
				case 'tiktok':
					$favicon = '🎵';
					break;
				case 'band':
					$favicon = '🟢';
					break;
				case 'line':
					$favicon = '💬';
					break;
				case 'reddit':
					$favicon = '👽';
					break;
				case 'discord':
					$favicon = '💬';
					break;
				default:
					$favicon = '🔗';
					break;
			}
		} else {
			// 우선순위 2: referer/도메인 기반 파악
			$ref = strtolower($log->referer);
			$domain = strtolower($log->ref_domain);

			if (strpos($ref, 'naver') !== false || $domain == 'naver.com') {
				$favicon = '🟩';
			} elseif (strpos($ref, 'daum') !== false || $domain == 'daum.net') {
				$favicon = '🟦';
			} elseif (strpos($ref, 'google') !== false || $domain == 'google.com') {
				$favicon = '🟥';
			} elseif (strpos($ref, 'bing') !== false || $domain == 'bing.com') {
				$favicon = '🔷';
			} elseif (strpos($ref, 'zoom') !== false || $domain == 'zum.com') {
				$favicon = '🟪';
			} elseif (strpos($ref, 'yahoo') !== false || $domain == 'yahoo.com') {
				$favicon = '🟣';
			} elseif (strpos($ref, 'duckduckgo') !== false) {
				$favicon = '🦆';
			} elseif (strpos($ref, 'baidu') !== false) {
				$favicon = '🇨🇳';
			} elseif (strpos($ref, 'yandex') !== false) {
				$favicon = '🇷🇺';
			} elseif (strpos($ref, 't.co') !== false || $domain == 't.co') {
				$favicon = '🐦';
			} elseif (strpos($ref, 'facebook') !== false) {
				$favicon = '🟦';
			} elseif (strpos($ref, 'instagram') !== false) {
				$favicon = '🟪';
			} elseif (strpos($ref, 'kakao') !== false) {
				$favicon = '🟨';
			} elseif (strpos($ref, 'tiktok') !== false) {
				$favicon = '🎵';
			} elseif (strpos($ref, 'linkedin') !== false) {
				$favicon = '🧑‍💼';
			} elseif (strpos($ref, 'pinterest') !== false) {
				$favicon = '📌';
			} elseif (strpos($ref, 'band') !== false) {
				$favicon = '🟢';
			} elseif (strpos($ref, 'line') !== false) {
				$favicon = '💬';
			} elseif (strpos($ref, 'reddit') !== false) {
				$favicon = '👽';
			} elseif (strpos($ref, 'discord') !== false) {
				$favicon = '💬';
			}
		}

		
		
		
		// 1. 기기 아이콘
		$device_icon = ($log->device_type == 'mobile') ? '📱' : '🖥️';

		// 2. 도착 페이지 정보
		$landing_url = $log->landing_page;
		$landing_display = display_url_clean($log->landing_page);

		// 3. 키워드 정보 (있으면 박스 생성, 없으면 빈 값)
		$keyword_html = '';
		if (!empty($log->keyword)) {
			// 🔍 아이콘 + 키워드
			$keyword_html = '<span class="keyword-tag">🔍 ' . esc_html($log->keyword) . '</span>';
		}

		// 4. 유입 출처 (위쪽 텍스트)
		$source_html = '';

		if ($log->ref_domain == 'direct') {
			$source_html = '<span class="origin-link" style="cursor:default; color:#999;">' . $device_icon . ' 🚫 직접 접속</span>';
		} 
		elseif ($log->social_platform != '' && empty($log->referer)) {
			$platform_name = ucfirst($log->social_platform);
			$source_html = '<span class="origin-link" style="cursor:default; color:#333;">' . $device_icon . ' ' . $favicon . ' ' . $platform_name . ' (앱 접속)</span>';
		}
		else {
			$link = esc_url($log->referer);
			$display_url = display_url_clean($log->referer);
			if (empty($display_url)) {
				$display_url = '알 수 없는 출처';
				$link = '#';
			}
			$source_html = '<a href="' . $link . '" target="_blank" class="origin-link">' . $device_icon . ' ' . $favicon . ' ' . esc_html($display_url) . '</a>';
		}

		// --- 출력 (HTML 구조 변경됨: .dest-wrap 추가) ---
		echo '<tr><td class="_link">';
		
		echo '<div class="split-link-wrap">';
		// (위) 출처
		echo $source_html;
		
		// (아래) [키워드 박스(있을때만)] + [도착 페이지 박스]
		echo '<div class="dest-wrap">';
			// 키워드가 있으면 여기에 출력됨
			echo $keyword_html; 
			// 도착 페이지 링크
			echo '<a href="' . esc_url($landing_url) . '" target="_blank" class="dest-link">📄 ' . esc_html($landing_display) . '</a>';
		echo '</div>'; // .dest-wrap 닫기

		echo '</div>'; // .split-link-wrap 닫기

		echo '</td>';
		echo '<td>' . esc_html($log->created_at) . '</td></tr>';
	
		
	}
    echo '</tbody></table>';

	// 페이징
	if ($total_pages > 1) {
		echo '<div class="tablenav"><div class="tablenav-pages">';

		$pages_per_block = 5;
		$current_block = floor(($paged - 1) / $pages_per_block);
		$start = $current_block * $pages_per_block + 1;
		$end = min($start + $pages_per_block - 1, $total_pages);

		// ≪ 처음
		if ($paged > 1) {
			$first_url = add_query_arg([
				'page' => 'referrer-paths',
				'start_date' => $start_date,
				'end_date' => $end_date,
				'paged' => 1
			]);
			echo '<a href="' . esc_url($first_url) . '">≪ 처음</a> ';
		}

		// « 이전 블록
		if ($start > 1) {
			$prev_block = $start - 1;
			$prev_url = add_query_arg([
				'page' => 'referrer-paths',
				'start_date' => $start_date,
				'end_date' => $end_date,
				'paged' => $prev_block
			]);
			echo '<a href="' . esc_url($prev_url) . '">« 이전</a> ';
		}

		// 숫자 페이지
		for ($i = $start; $i <= $end; $i++) {
			$url = add_query_arg([
				'page' => 'referrer-paths',
				'start_date' => $start_date,
				'end_date' => $end_date,
				'paged' => $i
			]);
			$current = ($i == $paged) ? ' style="font-weight:bold;"' : '';
			echo '<a href="' . esc_url($url) . '"' . $current . '> ' . $i . ' </a>';
		}

		// 다음 블록 »
		if ($end < $total_pages) {
			$next_block = $end + 1;
			$next_url = add_query_arg([
				'page' => 'referrer-paths',
				'start_date' => $start_date,
				'end_date' => $end_date,
				'paged' => $next_block
			]);
			echo '<a href="' . esc_url($next_url) . '">다음 »</a> ';
		}

		// 끝 ≫
		if ($paged < $total_pages) {
			$last_url = add_query_arg([
				'page' => 'referrer-paths',
				'start_date' => $start_date,
				'end_date' => $end_date,
				'paged' => $total_pages
			]);
			echo '<a href="' . esc_url($last_url) . '">끝 ≫</a>';
		}

		echo '</div></div>';
	}




    echo '</div>'; // .tamsaek-right
    echo '</div>'; // .tamsaek-flex-wrap
    echo '</div>'; // .wrap
}
?>