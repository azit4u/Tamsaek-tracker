<?php
require_once TAMSAEK_TRACKER_PATH . 'includes/page-stats.php';
require_once TAMSAEK_TRACKER_PATH . 'includes/page-paths.php';

add_action('admin_menu', function() {
    add_menu_page(
        'Tamsaek 유입 통계',
        'Tamsaek 유입 통계',
        'manage_options',
        'referrer-stats',
        'render_referrer_stats_page',
        'dashicons-chart-bar',
        80
    );

    add_submenu_page(
        'referrer-stats',
        '유입 통계',
        '유입 통계',
        'manage_options',
        'referrer-stats',
        'render_referrer_stats_page'
    );

    add_submenu_page(
        'referrer-stats',
        '유입 경로',
        '유입 경로',
        'manage_options',
        'referrer-paths',
        'render_referrer_path_page'
    );
});
