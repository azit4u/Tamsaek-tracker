<?php
add_action('init', 'referrer_logger_strict');

function referrer_logger_strict() {
    if (is_admin() || wp_doing_ajax() || is_user_logged_in()) return;

    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
	


    // 🚫 저장 제외 경로
    foreach (['/wp-includes/', '/wp-admin/', '/xmlrpc.php', '/.env', '/vendor/', '/wp-cron.php'] as $bad_path) {
        if (strpos($request_uri, $bad_path) !== false) return;
    }

    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (!$user_agent) return;
    if (stripos($user_agent, 'WordPress/') === 0) return;

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $device = wp_is_mobile() ? 'mobile' : 'pc';
    $landing_page = home_url(add_query_arg([], $_SERVER['REQUEST_URI']));
    $site_domain = parse_url(home_url(), PHP_URL_HOST);

    global $wpdb;

    $search_engine = '';
    $keyword = '';
    $ref_domain = '';
    $referer_query = '';
    $social_platform = '';
	


    // 🚫 일반적인 봇 제외
	$bot_keywords = [
		'bot',            // 일반적인 봇 (Googlebot, Bingbot 등)
		'crawl',          // 크롤러 (site auditor 등)
		'spider',         // 검색엔진 스파이더
		'preview',        // 링크 미리보기 (Slack, FB 등)
		'bidswitch',      // 광고 관련 트래픽
		'google-adstxt',  // Google ads.txt 봇
		'curl',           // 명령줄 요청
		'python',         // Python 기반 요청
		'wget',           // Linux 기본 다운로드 도구
		'java',           // Java 기반 HTTP 요청
		'libwww',         // 오래된 Perl/Lib 클라이언트
		'httpclient',     // 프레임워크 기반 HTTP 클라이언트
		'wordpress',      // WP 자체 pingback, update 요청
		'ias-or',         // IAS 광고 봇
		'ias-va',         // IAS 비디오 봇
		'ias-ie',         // IAS Internet Explorer UA
		'integralads',    // IAS 관련 UA
		'alittle',        // ALittle Client
		'censys',         // Censys 보안 스캐너
		'ahrefs',         // Ahrefs SEO 크롤러
		'mj12',           // Majestic SEO 봇
		'semrush',        // SEMrush 크롤러
		'shodan',         // Shodan 보안 스캐너
		'uptime',         // 모니터링 툴 (UptimeRobot 등)
		'monitor',        // 기타 모니터링 툴
		'nodefetch',      // Node.js 기반 자동화
		'urlgrabber',     // URL 수집기
		'go-http-client', // Go 언어 기반 봇
		'axios',          // JavaScript Axios 라이브러리
		'scrapy',         // Python Scrapy 프레임워크
		'mediapartners',  // Google AdSense 광고 크롤러
		'facebookexternalhit', // 페이스북/카카오 미리보기 요청
		'vizios',         // Vizio OS
		'vizio',          // Vizio TV
		'watchfree',      // Vizio WatchFree 앱
		'fancyplayer',    // Vizio 내장 플레이어
		'roku'            // Roku 셋탑박스
	];
    foreach ($bot_keywords as $bot) {
        if (stripos($user_agent, $bot) !== false) return;
    }


  // ✅ post_id 추출
    $post_id = url_to_postid($landing_page);
    if (!$post_id) {
        $path = wp_parse_url($landing_page, PHP_URL_PATH);
        $slug = trim($path, '/');
        $page = get_page_by_path($slug, OBJECT, ['post', 'page']);
        if ($page && isset($page->ID)) {
            $post_id = $page->ID;
        }
    }

    // ✅ post_id 없는 경우 저장 안 함
    if (!$post_id || !is_numeric($post_id) || get_post_status($post_id) !== 'publish') return;


      // SNS 인앱 감지
    $social_platform = detect_social_platform($user_agent, $referer);

    if ($referer) {
        $parsed_url = parse_url($referer);
        if ($parsed_url && isset($parsed_url['host'])) {
            $ref_domain = $parsed_url['host'];
            $referer_query = $parsed_url['query'] ?? '';
			$referer_path = $parsed_url['path'] ?? ''; // ✅ 바로 여기 추가!
        } else {
            $ref_domain = 'invalid_referer';
			$referer_path = $parsed_url['path'] ?? ''; // ✅ 바로 여기 추가!
        }

        // 내 도메인에서 온 경우 제외
        if ($ref_domain && strpos($ref_domain, $site_domain) !== false) return;

        // 검색엔진 키워드 추출
        parse_str($referer_query, $params);
        if (strpos($ref_domain, 'naver.') !== false) {
            $search_engine = 'naver';
            $keyword = $params['query'] ?? '';
        } elseif (strpos($ref_domain, 'daum.') !== false) {
            $search_engine = 'daum';
            $keyword = $params['q'] ?? '';
        } elseif (strpos($ref_domain, 'google.') !== false) {
            $search_engine = 'google';
            $keyword = $params['q'] ?? '';
        } elseif (strpos($ref_domain, 'zum.') !== false) {
            $search_engine = 'zum';
            $keyword = $params['query'] ?? '';
        } elseif (strpos($ref_domain, 'bing.') !== false) {
            $search_engine = 'bing';
            $keyword = $params['q'] ?? '';
        } elseif (strpos($ref_domain, 'yahoo.') !== false) {
            $search_engine = 'yahoo';
            $keyword = $params['p'] ?? '';
        }
    } elseif ($social_platform) {
        $ref_domain = $social_platform . '_inapp';
    } else {
        $ref_domain = 'direct';
    }

	// ✅ 중복 수집 방지 (같은 IP+리퍼러+URL이면 5분간 무시)
	$transient_key = 'tamsaek_log_' . md5($ip . $referer . $landing_page);
	if (get_transient($transient_key)) return;
	set_transient($transient_key, true, 5 * MINUTE_IN_SECONDS);



    // 중복 기록 방지
    $exists = $wpdb->get_var($wpdb->prepare("
        SELECT COUNT(*) FROM {$wpdb->prefix}referrer_stats
        WHERE log_date = %s AND ip_address = %s AND referer = %s AND landing_page = %s AND social_platform = %s
    ", current_time('Y-m-d'), $ip, $referer, $landing_page, $social_platform));
    if ($exists > 0) return;

    // 저장
    $wpdb->insert("{$wpdb->prefix}referrer_stats", [
        'log_date' => current_time('Y-m-d'),
        'ip_address' => $ip,
        'referer' => $referer,
		'referer_path' => $referer_path, // ✅ 여기에 추가
        'referer_query' => $referer_query,
        'search_engine' => $search_engine,
        'keyword' => $keyword,
        'landing_page' => $landing_page,
        'post_id' => $post_id, // ✅ post_id 저장
        'device_type' => $device,
        'user_agent' => $user_agent,
        'ref_domain' => $ref_domain,
        'social_platform' => $social_platform
    ]);
		
		
}

// SNS 감지 함수 유지
function detect_social_platform($user_agent, $referer = '') {
    $ua = strtolower($user_agent);
    if (strpos($ua, 'kakaotalk') !== false || strpos($ua, 'kakao') !== false) return 'kakao';
    if (strpos($ua, 'fban') !== false || strpos($ua, 'fbav') !== false || strpos($ua, 'fb_iab') !== false) return 'facebook';
    if (strpos($ua, 'instagram') !== false) return 'instagram';
    if (strpos($ua, 'threads') !== false) return 'threads';

    $ref = strtolower($referer);
    if (strpos($ref, 'facebook.com') !== false) return 'facebook';
    if (strpos($ref, 'instagram.com') !== false) return 'instagram';
    if (strpos($ref, 'kakao.com') !== false) return 'kakao';
    if (strpos($ref, 'threads.com') !== false) return 'threads';

    return '';
}




?>